import { Component } from '@angular/core';
import {Contact} from './contact'
import { UspsAddressApiService } from '../services/usps-address-api.service';
import { NgxXml2jsonService } from 'ngx-xml2json';

@Component({
  selector: 'contact-form',
  templateUrl: './contact.form.component.html',
  styleUrls: ['./contact.form.component.scss']
})
export class ContactFormComponet {
  submitted = false;
  myContact = new Contact(0,'','','','','','','','');
  isAlertVisible: boolean = false;

  constructor(private uspsAddressAPI : UspsAddressApiService,private ngxXml2jsonService: NgxXml2jsonService){}


  onSubmit(){ this.submitted = true;}

  ngDoCheck(){
      if(this.myContact.address1 != "" 
      && this.myContact.address2 != "" 
      && this.myContact.city != "" 
      && this.myContact.state != "")
      {
       
        this.uspsAddressAPI.getZipCodes(this.myContact)
        .subscribe((data:any) => { 
            const parser = new DOMParser();
            const xml = parser.parseFromString(data, 'text/xml');
            const obj : any = this.ngxXml2jsonService.xmlToJson(xml);
            console.log(obj);
            //this.myContact.zip = obj.ZipCodeLookupResponse.Address.Zip5;
        
        } );

          //this.myContact.zip = "48375";
          this.myContact.address2 = '';
      }
      else
      {
          console.log("NO Change");
      }
  }
  showAlert() : void {
    if (this.isAlertVisible) { // if the alert is visible return
      return;
    } 
    this.isAlertVisible = true;
    setTimeout(()=> this.isAlertVisible = false,9500); // hide the alert after 2.5s
  }
}