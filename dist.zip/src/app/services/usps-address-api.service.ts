import { Injectable } from '@angular/core';
import {HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import { Contact } from '../Contact/contact';
import { Observable } from 'rxjs';
import { NgxXml2jsonService } from 'ngx-xml2json';

@Injectable({
  providedIn: 'root'
})
export class UspsAddressApiService {

  constructor(private httpClient : HttpClient) { }

  public getZipCodes(contact:Contact): Observable<any>{
    var param = {'API' : 'ZipCodeLookup',
     'XML' : `<ZipCodeLookupRequest USERID="061MIMUT1289"><Address ID="0"><Address1>911 Military St</Address1><City>Port Huron</City><State>MI</State></Address></ZipCodeLookupRequest>`};

      //  params = params.append('API', 'ZipCodeLookup');
      //  params = params.append('XML', encodeURIComponent(`<ZipCodeLookupRequest USERID="061MIMUT1289">
      //  <Address ID="0"><Address1>911 Military St</Address1><City>Port Huron</City><State>MI</State></Address>
      // </ZipCodeLookupRequest>`));
      // let myHeaders = new Headers();
      // myHeaders.append('Content-Type', 'application/json'); 

    // return this.httpClient.post('https://secure.shippingapis.com/shippingapi.dll',param);
   let myHeaders = new HttpHeaders();
   myHeaders.append('Content-Type', 'application/json'); 
   myHeaders.append('Accept', 'application/xml');
   var url = `https://secure.shippingapis.com/shippingapi.dll?API=ZipCodeLookup&XML=<ZipCodeLookupRequest USERID="061MIMUT1289"><Address ID="0"><Address1>911 Military St</Address1><City>Port Huron</City><State>MI</State></Address></ZipCodeLookupRequest>`;
   return this.httpClient.post(url,null,{headers : myHeaders,responseType : 'text'});
   
    
  //   (`https://secure.shippingapis.com/shippingapi.dll?API=ZipCodeLookup &XML=<ZipCodeLookupRequest USERID="061MIMUT1289">
  //   <Address ID="0"><Address1>911 Military St</Address1><City>Port Huron</City><State>MI</State></Address>
  //  </ZipCodeLookupRequest>`);
  }
  API_Key = '3fd81987f545495d8ec7fc1e7d8d676e';
  public getNews(){
    
    return this.httpClient.get(`https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=${this.API_Key}`)
  }

  public getFixedZip()
  {
    return this.httpClient.get(`https://secure.shippingapis.com/shippingapi.dll?API=ZipCodeLookup &XML=<ZipCodeLookupRequest USERID="061MIMUT1289">
    <Address ID="0"><Address1>911 Military St</Address1><City>Port Huron</City><State>MI</State></Address>
   </ZipCodeLookupRequest>`);
  }
}
