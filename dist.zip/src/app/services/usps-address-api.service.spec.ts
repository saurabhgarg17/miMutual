import { TestBed } from '@angular/core/testing';

import { UspsAddressApiService } from './usps-address-api.service';

describe('UspsAddressApiService', () => {
  let service: UspsAddressApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UspsAddressApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
